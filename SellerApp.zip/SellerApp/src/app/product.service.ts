import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { from, Observable } from 'rxjs';
import { ApiResponse } from './api.response';




@Injectable({
  providedIn: 'root'
})
export class ProductService {

  private baseUrl = 'http://localhost:6579';



  constructor(private http: HttpClient) { }

 
additems(ItemEntity:object):Observable<any> 
{ 
  console.log(ItemEntity);
  return this.http.post(`http://localhost:6579/items/3/add`,ItemEntity);
}
deleteitem(itemId:number):Observable<any>
{
  console.log("enter to delete");
  return this.http.delete(`${this.baseUrl}/items/${itemId}/deletebyid`)
}

updateitems(ItemEntity:object):Observable<any> 
{ 
  console.log(ItemEntity);
  console.log("in service");
  return this.http.put(`http://localhost:6579/items/15/update`,ItemEntity)
}



addseller(SellerEntity:object):Observable<any>
{
  
  console.log("in sellerservice method");
  console.log(SellerEntity);
  return this.http.post(`${this.baseUrl}/seller/add`,SellerEntity);
}


login(loginpayload:object):Observable<ApiResponse>
{  
  console.log("in login service method");
  console.log(loginpayload);
   return this.http.post<ApiResponse>(`http://localhost:6579/token/generate-token`,loginpayload);
}


}


