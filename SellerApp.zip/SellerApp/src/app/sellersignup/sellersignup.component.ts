import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { SellerEntity } from '../seller';

@Component({
  selector: 'app-sellersignup',
  templateUrl: './sellersignup.component.html',
  styleUrls: ['./sellersignup.component.css']
})
export class SellersignupComponent implements OnInit {

  
	sellerName:String;
	 sellerPass:String;
	 sellercmyName:String;
	 cmyDescription:String;
sellerAddress:String;
	sellerWebsite:String;
   sellerEmail:String;
    sellerMobile:String;
  constructor(private service:ProductService) { }
  seller:SellerEntity;

  addseller()
  {
    this.seller=new SellerEntity();
    this.seller.sellerName=this.sellerName;
    this.seller.sellerPass=this.sellerPass;
    this.seller.sellerEmail=this.sellerEmail;
    this.seller.sellerMobile=this.sellerMobile;
    this.seller.sellerAddress=this.sellerAddress;
    this.seller.sellercmyName=this.sellercmyName;
    this.seller.cmyDescription=this.cmyDescription;
    this.seller.sellerWebsite=this.sellerWebsite;
    console.log("in sellerts" + this.seller);
    this.service.addseller(this.seller).subscribe(SellerEntity=>this.seller=SellerEntity);
  }

  ngOnInit(): void {
  }

}


