import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { ItemEntity } from '../items';

@Component({
  selector: 'app-seller',
  templateUrl: './seller.component.html',
  styleUrls: ['./seller.component.css']
})
export class SellerComponent implements OnInit {

itemId:number;
itemPrice:number;
itemName:String;
description:String;
stockNumber:number;
remarks:String;
deleteItem:number;
items:ItemEntity=new ItemEntity();

  constructor(private sService: ProductService) { }

  ngOnInit(): void {
  }
  additems() 
  {
this.items.itemName=this.itemName;
this.items.itemPrice=this.itemPrice;
this.items.description=this.description;
this.items.stockNumber=this.stockNumber;
this.items.remarks=this.remarks;
this.sService.additems(this.items).subscribe(ItemEntity=>this.items=ItemEntity);

  } 
  deleteitem() 
  { 
    console.log("in .ts");
    this.sService.deleteitem(this.deleteItem).subscribe(Itemlist=>this.items=this.items)
  }
  updateitem() 
  {
    console.log("in update");
    this.items.itemName=this.itemName;
    this.items.itemPrice=this.itemPrice;
    this.items.description=this.description;
    this.items.stockNumber=this.stockNumber;
    this.items.remarks=this.remarks;
    this.sService.updateitems(this.items).subscribe(Itemlist=>this.items=this.items);
  }


}
