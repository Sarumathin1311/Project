export class ItemEntity{

    itemId:number;
    categoryId:number;
    subcategoryId:number;
    itemPrice:number;
    itemName:String;
    description:String;
    stockNumber:number;
    remarks:String;

   
}
