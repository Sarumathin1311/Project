package com.demo.service;

import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;

import com.demo.model.InventoryEntity;
import com.demo.repository.Inventoryrepository;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;


@Service
public class Inventoryservice {
	@Autowired
	private Inventoryrepository inventoryrepository;

	
		public Optional<InventoryEntity> getProduct(@PathVariable Integer productid) {
			return inventoryrepository.findById(productid);

}
}
