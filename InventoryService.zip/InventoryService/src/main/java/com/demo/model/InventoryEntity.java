package com.demo.model;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;

import javax.persistence.Id;

@Entity
public class InventoryEntity {
	
	@Id
	@GeneratedValue
	private int productId;
	
	private int productQty;

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public int getProductQty() {
		return productQty;
	}

	public void setProductQty(int productQty) {
		this.productQty = productQty;
	}

	public InventoryEntity(int productId, int productQty) {
		super();
		this.productId = productId;
		this.productQty = productQty;
	}

	public InventoryEntity() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "InventoryEntity [productId=" + productId + ", productQty=" + productQty + "]";
	}
	
	
}
