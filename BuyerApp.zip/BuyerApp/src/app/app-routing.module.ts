import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DisplaycartComponent } from './displaycart/displaycart.component';
import { SearchproductComponent } from './searchproduct/searchproduct.component';
import { BuyersignupComponent } from './buyersignup/buyersignup.component';


import { HomeComponent} from './home/home.component';
import { LoginComponent} from './login/login.component';
import { CheckoutComponent} from './checkout/checkout.component';
import { PurchasehistoryComponent } from './purchasehistory/purchasehistory.component';
import { TransactionComponent } from './transaction/transaction.component';
import { LogoutComponent } from './logout/logout.component';


const routes: Routes = [
  {path : 'buyersign',component:BuyersignupComponent},
  {path : 'searchproduct',component:SearchproductComponent},
  {path : 'displaycart' , component:DisplaycartComponent},
  {path:'home',component:HomeComponent},
  {path:'login',component:LoginComponent},
  {path:'checkout',component:CheckoutComponent},
  {path:'purchaseHistory',component:PurchasehistoryComponent},
  {path:'transaction',component:TransactionComponent},
  {path:'logout',component:LogoutComponent}
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
