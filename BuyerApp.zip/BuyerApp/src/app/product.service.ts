import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { from, Observable } from 'rxjs';
import { shoppingcart } from './cart';
import { TransactionEntity } from './transaction';
import { ApiResponse } from './api.response';



@Injectable({
  providedIn: 'root'
})
export class ProductService {

  private baseUrl = 'http://localhost:6578';



  constructor(private http: HttpClient) { }

  getItems(itemName: string) : Observable<any> {
    console.log(itemName);

    return this.http.get(`http://localhost:6579/items/searchbyname/${itemName}`);
  }
  addToCart(cart:shoppingcart):Observable<any> {
return this.http.post(`http://localhost:6578/cart/1/add`,cart);


  }

displayCartItems() : Observable<any>{

return this.http.get(`http://localhost:6578/cart/1/getAll`);

}


addbuyer(BuyerEntity:object):Observable<any>
{ 
  
console.log("in last ts");
console.log(BuyerEntity);
  return this.http.post(`${this.baseUrl}/buyer/add`,BuyerEntity);
}

updateCartItems(cart:shoppingcart,cartId:number,):Observable<any>{
  return this.http.put(`${this.baseUrl}/cart/${cartId}/update`,cart);
}

deletecartItems(cartId:number)
{
  return this.http.delete(`${this.baseUrl}/cart/${cartId}/deletebyid`,);
}

emptyCart()
{
  return this.http.delete(`${this.baseUrl}/cart/2/deleteall`,);
}


displaypurchaseItems() :Observable<any>
{
  return this.http.get(`http://localhost:6578/purchase/1/getAll`);
}

CheckoutCart(transaction:TransactionEntity): Observable<any> {
  
  return this.http.post(`http://localhost:6578/cart/1/checkout`,transaction);
  window.alert("checkout done successfully");
}


displaytransactionItems() :Observable<any>
{
  return this.http.get(`http://localhost:6578/transaction/1/getAll`);
}


login(loginpayload:object):Observable<ApiResponse>
{  
  console.log("in login service method");
  console.log(loginpayload);
   return this.http.post<ApiResponse>(`http://localhost:6578/token/generate-token`,loginpayload);
}

}


