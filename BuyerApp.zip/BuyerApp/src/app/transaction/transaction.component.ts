import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { TransactionEntity } from '../transaction';

@Component({
  selector: 'app-transaction',
  templateUrl: './transaction.component.html',
  styleUrls: ['./transaction.component.css']
})
export class TransactionComponent implements OnInit {
  
  transaction:TransactionEntity[];
  constructor(private pservice:ProductService) { }

  ngOnInit(): void {
    this.pservice.displaytransactionItems().subscribe( transaction=> this.transaction=transaction);
    console.log(this.transaction);
  }

}
