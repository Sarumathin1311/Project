import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { BuyerEntity } from '../buyer';

@Component({
  selector: 'app-buyersignup',
  templateUrl: './buyersignup.component.html',
  styleUrls: ['./buyersignup.component.css']
})
export class BuyersignupComponent implements OnInit {
buyerName:String;
buyerPass:String;
buyerEmail:String;
buyerMobile:number;
buyer:BuyerEntity;
  constructor(private service:ProductService) { }
  addbuyer()
  {
    this.buyer=new BuyerEntity();
    this.buyer.buyerName=this.buyerName;
    this.buyer.buyerPass=this.buyerPass;
    this.buyer.buyerEmail=this.buyerEmail;
    this.buyer.buyerMobile=this.buyerMobile;
    console.log("In Service ts");
    console.log(this.buyer);
    this.service.addbuyer(this.buyer).subscribe(newbuyer=>this.buyer=newbuyer);
  }
  ngOnInit(): void {
  }

}
