import { Component, OnInit } from '@angular/core';
import { BuyerEntity } from '../buyer';
import { ProductService } from '../product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  username:String;
  password:number;
  buyer :BuyerEntity=new BuyerEntity();
  constructor(private routerService:Router ,private lservice:ProductService) { }

  ngOnInit(): void {
  }
  login()
  {
    console.log("in login method");
    const loginPayload = {
    username: this.username,
    password: this.password
  }
  this.lservice.login(loginPayload).subscribe(data=>{
    debugger;
    if(data.result.token !== null) {
      alert("successs");
      console.log("in subscribe method");
      window.localStorage.setItem('token', data.result.token);
      window.localStorage.setItem('buyerId',data.result.buyerId);
      window.localStorage.setItem('username',data.result.username);
      console.log(data.result.token);
      this.routerService.navigate(['searchproduct']);
    }else {
      
      alert("incorrect password");
    }
  });
  }
}
