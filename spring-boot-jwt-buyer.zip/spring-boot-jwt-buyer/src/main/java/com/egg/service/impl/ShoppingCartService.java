package com.egg.service.impl;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.egg.dao.BuyerDao;
import com.egg.dao.PurchaseDao;
import com.egg.dao.ShoppingCartDao;
import com.egg.dao.TransactionDao;
import com.egg.model.BuyerEntity;
import com.egg.model.PurchaseHistoryEntity;
import com.egg.model.ShoppingCartEntity;
import com.egg.model.TransactionEntity;



@Service
public class ShoppingCartService {
	
	@Autowired
	private ShoppingCartDao shoppingcartDao;
	
	@Autowired
	private BuyerDao buyerDao;
	
	@Autowired
	private TransactionDao transactionDao;
	
	@Autowired
	private PurchaseDao purchaseDao;
	
	public List<ShoppingCartEntity> getAllCartItems(Integer buyerId){
		return shoppingcartDao.getAllCartItems(buyerId);
	}
	
	public Optional<ShoppingCartEntity> addCartItem(ShoppingCartEntity shoppingCartItem, Integer buyerId) {
		return buyerDao.findById(buyerId).map(buyer -> {
			shoppingCartItem.setBuyerId(buyer);
			return shoppingcartDao.save(shoppingCartItem);
		});
		
	}
	
	public String deleteCartItemById(Integer Id) {
		shoppingcartDao.deleteById(Id);
		return "Item with cartId "+Id+" is deleted.";
	}
	
	public void emptyCart(Integer buyerId) {
	
		shoppingcartDao.emptyCart(buyerId);
	}
	
	public ShoppingCartEntity updateCart(ShoppingCartEntity shoppingCartItem, Integer Id) {
		ShoppingCartEntity shoppingcart = null;
		Optional<ShoppingCartEntity> cartItem = shoppingcartDao.findById(Id);
		
		if(cartItem.isPresent())
		{
		shoppingcart = cartItem.get();
		shoppingcart.setItemId(shoppingCartItem.getItemId());
		shoppingcart.setItemQuantity(shoppingCartItem.getItemQuantity());
		shoppingcart.setItemDescription(shoppingCartItem.getItemDescription());
		
		return shoppingcartDao.save(shoppingcart);
		}
		return null;
		
		
		
		
	}

	public String checkOut(TransactionEntity transaction, int buyerid) 
	{
		BuyerEntity buyerEntity=buyerDao.getOne(buyerid);
		System.out.println(buyerEntity);
		transaction.setBuyerEntity(buyerEntity);
		System.out.println(transaction);
		transactionDao.save(transaction);
		List<ShoppingCartEntity> cart1=shoppingcartDao.getAllCartItems(buyerid);
		for(int i=0;i<cart1.size();i++)
		{
			PurchaseHistoryEntity pHistory=new PurchaseHistoryEntity();
			ShoppingCartEntity sCart=cart1.get(i);
			int size=sCart.getItemQuantity();
			String iname=sCart.getItemName();
			int iprice=sCart.getItemPrice();
			pHistory.setNumberofItems(size);
			pHistory.setBuyerEntity(buyerEntity);
			pHistory.setItemName(iname);
			pHistory.setItemPrice(iprice);
			System.out.println(pHistory);
			shoppingcartDao.deleteById(sCart.getCartId());
			purchaseDao.save(pHistory);
			
		}
		return null;
	}
	

}


