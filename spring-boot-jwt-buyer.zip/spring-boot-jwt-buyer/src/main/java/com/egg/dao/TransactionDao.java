package com.egg.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.egg.model.TransactionEntity;


@Repository
public interface TransactionDao extends JpaRepository<TransactionEntity, Integer>
{
	@Query(value = "SELECT * FROM transaction_entity c WHERE c.buyer_id = :buyerId"
			,nativeQuery = true)
	public List<TransactionEntity> getallTransactionitems(@Param("buyerId")Integer buyerId);
}
