/*Transaction Entity Class*/
package com.egg.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;



@Entity
public class TransactionEntity {
	
	@Id
	@GeneratedValue
	private int transactionId;
	private String transactionType;

	
	@CreationTimestamp
	@Temporal(TemporalType.TIMESTAMP)
	private Date transactionDate;
	

	
	@ManyToOne
	@JoinColumn(name="buyerId")
    private BuyerEntity buyerEntity;
	
	/*@ManyToOne
	@JoinColumn(name="sellerId")
    private SellerEntity sellerEntity;*/

	public TransactionEntity() {
		
		// TODO Auto-generated constructor stub
	}

	public TransactionEntity(int transactionId, String transactionType, Date transactionDate, BuyerEntity buyerEntity) {
		super();
		this.transactionId = transactionId;
		this.transactionType = transactionType;
		this.transactionDate = transactionDate;
		this.buyerEntity = buyerEntity;
	}

	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public Date getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}

	public BuyerEntity getBuyerEntity() {
		return buyerEntity;
	}

	public void setBuyerEntity(BuyerEntity buyerEntity) {
		this.buyerEntity = buyerEntity;
	}

	@Override
	public String toString() {
		return "TransactionEntity [transactionId=" + transactionId + ", transactionType=" + transactionType
				+ ", transactionDate=" + transactionDate + ", buyerEntity=" + buyerEntity + "]";
	}

	
	

	
	
	
}
