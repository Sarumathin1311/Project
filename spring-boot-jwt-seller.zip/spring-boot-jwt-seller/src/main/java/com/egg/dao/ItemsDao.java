package com.egg.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.egg.model.ItemsEntity;




@Repository
public interface ItemsDao extends JpaRepository<ItemsEntity, Integer>{
	@Transactional
	@Modifying
	@Query(value = "DELETE FROM ItemsEntity WHERE ItemsEntity.sellerId = :sellerId",nativeQuery = true)
	public void deleteall(@Param("sellerId")Integer sellerId);
	
	

	@Query(value = "SELECT * FROM ItemsEntity c WHERE c.sellerId = :sellerId"
			,nativeQuery = true)
	public List<ItemsEntity> getAllItems(@Param("sellerId")Integer sellerId);
	
	
	
	
	@Query(value="from ItemsEntity where itemName like %:itemName% ")
	public List<ItemsEntity>finditem(@Param("itemName") String itemname);

}
